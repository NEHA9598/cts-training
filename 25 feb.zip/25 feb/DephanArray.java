package JvaPrograms;
//import java.util.*;


public class DephanArray
{
	public static void main(String args[])
	{

	     int arr[]= {4,8,6,3,2,9,8,11,8,13,12,12,6};
		 int n,num1,Result,numLast,numMid;
		   for( n=0; (n<numMid); n++) 
		   {
		    if ((arr[num1]%2) || (arr[numLast - num1]%2)) {
		    
		    }
		   
		  }
	}
		 
		 }