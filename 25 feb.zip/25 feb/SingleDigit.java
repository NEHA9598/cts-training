package JvaPrograms;
import java.util.*;
public class SingleDigit {

	public static void main(String args[])
	{
		
		int num,sum=0,lastdigit,input,count=0;
		Scanner sc=new Scanner(System.in);
		System.out.println("enter a no of your choice");
		num=sc.nextInt();
		input=num;
		while(input!=0)
		{
		 lastdigit=input%10;
		 sum=sum+lastdigit;
		 input=input/10;
		 
		}
		System.out.println("Original num" +num );
		System.out.println("sum of digits="+sum);
		while(sum!=0)
		{
			sum=sum/10;
			count++;
		}
		System.out.println("count"+count);
	}
}
